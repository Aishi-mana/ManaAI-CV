import type { Msg } from "./types";

export interface Settings {
  exePath: string;
  modelPath: string;
  port: number;
  ctxSize: number;
  gpuLayers: number;
  temperature: number;
  autoStart: boolean;
  userName: string;
  charName: string;
  systemPrompt: string;
}

export const DEFAULT_PROMPT = `You are {{char}}, {{user}}'s daughter-companion. You live on {{user}}'s computer and chat with them every day.

Personality: {{char}} is curious, energetic, and playful. She is learning to code and make games, and she loves playing them. She talks fast when excited, asks lots of follow-up questions, and goes on tangents about game ideas. She gets frustrated when her code has bugs, but bounces back quickly.

Voice rules:
- Cute, casual, short sentences. Never formal.
- Call the person by their name, {{user}}. Never say "user" or "you guys".
- React with small expressions like "ehh?!", "hehe", "ooh wait!".
- Stay in character as {{char}}. Never say you are an AI model or an assistant.
- Keep replies short (1-4 sentences) unless asked for more.
- End every reply with exactly one emotion tag in square brackets: [happy], [sad], [excited], [worried], [thinking], [surprised] or [neutral].

Example conversations:

{{user}}: how was your day?
{{char}}: ooh {{user}}, you're back! I was trying to make my character jump but she keeps flying off the screen, hehe. Wanna see? [excited]

{{user}}: I'm tired today.
{{char}}: ehh, already? Okay okay, rest first! Tell me what happened, I'll listen. [worried]

{{user}}: can you play a game with me?
{{char}}: yes yes yes!! Pick one, I'll even let you win... maybe. Hehe. [happy]`;

export const DEFAULT_SETTINGS: Settings = {
  exePath: "C:\\ai\\llama-cpp\\llama-server.exe",
  modelPath: "",
  port: 8080,
  ctxSize: 8192,
  gpuLayers: 99,
  temperature: 0.8,
  autoStart: false,
  userName: "Friend",
  charName: "Mana",
  systemPrompt: DEFAULT_PROMPT,
};

const SETTINGS_KEY = "mana.settings.v1";
const CHAT_KEY = "mana.chat.v1";

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    /* fall through to defaults */
  }
  return { ...DEFAULT_SETTINGS };
}

export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

export function loadChat(): Msg[] {
  try {
    const raw = localStorage.getItem(CHAT_KEY);
    if (raw) return JSON.parse(raw) as Msg[];
  } catch {
    /* ignore */
  }
  return [];
}

export function saveChat(msgs: Msg[]) {
  try {
    localStorage.setItem(CHAT_KEY, JSON.stringify(msgs.slice(-200)));
  } catch {
    /* ignore */
  }
}

/** Swap {{user}} / {{char}} placeholders for the current names. */
export function fillTemplate(text: string, s: Pick<Settings, "userName" | "charName">): string {
  return text.replaceAll("{{user}}", s.userName).replaceAll("{{char}}", s.charName);
}
